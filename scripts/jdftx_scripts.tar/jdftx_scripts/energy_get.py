import os

class GetEnergy(object):
# """
# A class to read jdftx files and store the energy values to output file.
# Input: Charged-.*.out files
# Output: Dir_energy.txt
# """
    def __init__(self):
        self.file_path = os.getcwd()
        self.file_name = self.file_path.split("/")[-1] + "_energy.txt"
        self.files = sorted([file for file in os.listdir(".") if file.startswith("Charged-") and file.endswith(".out")])
        self.write_file = self.file_path + "/" + self.file_name

    def read_output(self, file):  # list all the .out file and find the energy line.
        read_file = self.file_path + "/" + file
        with open(read_file, "r") as f:
            lines = f.readlines()
        for line in lines:
            if "G =   " in line:
                return (file + line)
            else:
                pass

    def writ_to_energy(self, energy):  # write the energy line to the output file.
        # print(energy)
        with open(self.write_file, "a") as f:
            if energy == None:
                pass
            else:
                f.write(energy)

    def run(self):
        if os.path.exists(self.write_file):
            pass
        else:
            for file in self.files:
                energy = self.read_output(file)
                self.writ_to_energy(energy)
        return self.file_name


