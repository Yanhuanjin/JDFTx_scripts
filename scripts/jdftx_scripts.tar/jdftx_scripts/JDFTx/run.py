#!/usr/bin/env python
from energy_plot import Plot
from energy_get import GetEnergy


def main():
    energy = GetEnergy()
    energy_file = energy.run()
    ploter = Plot(energy_file)
    ploter.run()


if __name__ == "__main__":
    main()
