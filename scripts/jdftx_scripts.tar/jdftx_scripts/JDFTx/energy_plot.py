import matplotlib.pyplot as plt
import re


class Plot(object):
    def __init__(self, filename):
        self.filename = filename

    def get_energy(self):
        with open(self.filename, "r") as f:
            lines = f.readlines()
        energy_list = list()
        potential_list = list()
        regex = re.compile(r"(Charged-)(.*)(.out)")
        for line in lines:
            energy = float(line.split("    ")[-1].strip("\n"))
            potential_temp = line.split("    ")[0]
            energy_list.append(energy)
            potential = regex.match(potential_temp).group(2)
            potential_list.append(potential)
        return energy_list, potential_list

    def plot(self, energy_list, potential_list):
        plt.title("Energy vs Potential")
        plt.xlabel("Potential / Hartree")
        plt.ylabel("Energy / Hartree")
        plt.plot(potential_list, energy_list, marker="x")
        file_name = self.filename.split(".")[0] + ".png"
        plt.savefig(file_name)

    def run(self):
        energy_list, potential_list = self.get_energy()
        self.plot(energy_list, potential_list)


