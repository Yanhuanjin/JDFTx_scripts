import os

class GetEnergy(object):
    def __init__(self):
        self.file_path = os.getcwd()
        self.file_name = self.file_path.split("/")[-1] + "_energy.txt"
        self.files = [file for file in os.listdir(".") if file.startswith("Charged-") and file.endswith(".out")]
        self.write_file = self.file_path + "/" + self.file_name

    def read_output(self, file):
        read_file = self.file_path + "/" + file
        with open(read_file, "r") as f:
            lines = f.readlines()
        for line in lines:
            if "G =   " in line:
                return (file + line)
            else:
                pass

    def writ_to_energy(self, energy):
        print(energy)
        with open(self.write_file, "a") as f:
            if energy == None:
                pass
            else:
                f.write(energy)

    def run(self):
        for file in self.files:
            energy = self.read_output(file)
            self.writ_to_energy(energy)
        return self.file_name


