#!/bin/bash
# Created by YHJin 2019-07-13 12:43
# Description: Generate the INPUT of jdftx fix_potential calculations.
xsd2pos2
cp ~/example/jdftx/fix_potential/* ./
createLattice.py POSCAR
createStructure.py POSCAR
rm KPOINTS POSCAR
