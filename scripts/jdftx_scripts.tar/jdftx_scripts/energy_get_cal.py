#!/usr/bin/env python
# Created by YHJin 2019-09-06 15:08
# Description: After a row of jdftx fix_potential calculations,
#              run this script to get energy(dir.txt) and plot a energyprofile(dir.png)
# Usage: energy_get_plot.py or python energy_get_plot.py

from energy_cal import Plot
from energy_get import GetEnergy


def main():
    # print("\nJDFTx ploter -by YHJin")
    # print("*"*11 + " Try to get the energy and plot. " + "*"*11)
    energy = GetEnergy()
    energy_file = energy.run()
    ploter = Plot(energy_file)
    ploter.run()
    # print("*"*24 + " Done. " + "*"*24 + "\n")


if __name__ == "__main__":
    main()
