#!/bin/bash 
#PBS -N test
#PBS -r n 
#PBS -j oe 
#PBS -l walltime=256:00:00
#PBS -l nodes=1:v4:ppn=8
#PBS -q xmcao

source /data/intel-env/intel17_impi5_env.sh
#source /home/apps/intel/composer_xe_2015.0.090/bin/compilervars.sh intel64
#source /home/apps/intel/impi/5.0.1.035/intel64/bin/mpivars.sh
# go to work dir
cd $PBS_O_WORKDIR
# The program we want to execute (modify to suit your setup)
EXEC=/data/software/apps/jdftx-master/jdftx/build/jdftx
#EXEC=/data/apps/vasp/5.4.1/AllInOne/vasp_std

# setup mpd env (Of course use some other secret word than "dfadfs")
##if [ ! -f ~/.mpd.conf ]; then
##/bin/echo "secretword=dfadfs" >> ~/.mpd.conf
##/bin/chmod 600 ~/.mpd.conf
##fi

##########################################################
# The following should be no need to
#       change any of these settings for normal use.
##########################################################

# setup Nums of Processor
NP=`cat $PBS_NODEFILE|wc -l`
echo "Numbers of Processors:  $NP"
echo "---------------------------"
echo `date`
cat $PBS_NODEFILE | uniq

# setup mpi env (em64t)
export OMP_NUM_THREADS=1
#export P4_GLOBMEMSIZE=1073741824
export I_MPI_PIN_DOMAIN=auto
export MPD_CON_EXT=$PBS_JOBID

startime=`date +%s`
# mpirun --mca btl tcp,self --bind-to socket -np $NP -hostfile $PBS_NODEFILE  $EXEC -c 1 -i input.in -o output.out 2>&1 | tee print-out
for iMu in {-10..10..2}; do
    export mu="$(echo $iMu | awk '{printf("%.4f", -4.4/27.2114+0.1*$1/27.2114)}')"
    mpirun -np $NP -hostfile $PBS_NODEFILE $EXEC -c 1 -i Charged.in | tee Charged$mu.out
    mv common.nbound Charged$mu.nbound
done
endtiime=`date +%s`
DeltaTime=$((endtiime - startime))
timesec=$((DeltaTime % 60))
timetotmin=$((DeltaTime / 60))
timemin=$((timetotmin % 60))
timetothr=$((timetotmin / 60))
timehr=$((timetothr % 24))
timetotday=$((timetothr / 24))
printf " %s  TimeUsed:    %1dd%02dhr%02dmin%02ds \n"  `date +%Y-%m-%d/%H:%M` $timetotday $timehr $timemin $timesec >> $HOME/finish
echo `pwd` >>  $HOME/finish
