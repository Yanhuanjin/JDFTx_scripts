#!/usr/bin/env python
import os
import re
def find_file():
    files = os.listdir('./')
    regex = re.compile("(Charged-)(.*)(.out)")
    for file in files:
        ret = regex.match(file)
        if ret:
            charge_file = ret.group(0)
            xsf_file = ret.group(2) + ".xsf"
            nbound_file = ret.group(1) + ret.group(2) + ".nbound"
            print("Creating XSF file: " + xsf_file)
            os.system('createXSF ' + charge_file + " " + xsf_file + " " + nbound_file)
            # os.system('sz ' + xsf_file)
        else:
            pass

find_file()
